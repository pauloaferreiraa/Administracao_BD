package bench;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Populate {
    public static void main(String[] args) throws Exception {
        Connection c = DriverManager.getConnection("jdbc:postgresql://localhost/invoices");

        Statement s = c.createStatement();

        s.executeUpdate("create table cliente (id int, nome varchar, addr varchar)");
        s.executeUpdate("create table cliente (id int, nome varchar, addr varchar)");

        for(...)
            s.executeUpdate("insert into cliente values (1, 'cli 1', 'endereço 1')");


        for(...)
        s.executeUpdate("insert into prod values (1, 'cli 1', 'endereço 1')");

        s.close();
        c.close();

    }
}
