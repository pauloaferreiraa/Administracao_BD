package bench.abd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class Run extends Thread {

    public void run() {
        Connection c = ...;
        Statement s = ...;

        for(...) {
            switch(rand) {
                case 0:
                    int no, cli, prod;

                    cli = rand.nextInt(MAX)|rand.nextInt(MAX);

                    // alternativa 1 - não recomendada!!!
                    s.executeUpdate("insert into invoices values ("+no+","+cli+","+prod+")");

                    // alternativa 2 - recomendaa!
                    PreparedStatement ps = c.prepareStatement("insert into invoices values (?,?.?)");
                    ps.setInt(1, no);
                    ps.setInt(2, cli);
                    ps.setInt(3, prod);
                    ps.executeUpdate();
                case 1:
                    ResultSet rs = s.executeQuery("select ..");

                    while (rs.next()) {
                        ...
                    }
                case 2:
                    top 10
            }
        }
    }

    public static void main(String[] args) {
        for(...)
            new Run();
    }
}
