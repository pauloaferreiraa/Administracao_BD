package bench.abd;

import java.sql.*;
import java.util.Random;

public class Run extends Thread {

    // Gerar o numero da fatura
    private static int n = 0;

    private static synchronized int next() {
        return n++;
    }

    private static long ultima = -1;

    private static long iaa = 0, tra = 0, c = 0;
    private static boolean start = false;

    private static synchronized void regista(long antes, long depois) {


        long tr = depois-antes;

        long anterior = ultima;
        ultima = depois;

        if (anterior < 0 || !start)
            return;

        long ia = depois - anterior;

        iaa += ia;
        tra += tr;
        c++;
    }

    public static synchronized void partida() {
        start = true;
    }

    public static synchronized void imprime() {
        double trm = (tra/1e9d)/c;
        double debito = 1/((iaa/1e9d)/c);

        System.out.println("debito = "+debito+" tps, tr = "+trm+" s");

    }

    public void run() {

        Random r = new Random();

        // 1 para cada thread!
        //Connection c = DriverManager.getConnection("...");
        //Statement s = ...;

        while(true) {

            long antes = System.nanoTime();

            // EXECUTAR OP! (switch, executeQuery, ...)

            /*
            ResultSet rs = s.executeQuery("...");
            while(rs.next())
                ;
               */

            try {
                Thread.sleep(r.nextInt(2000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            // ---

            long depois = System.nanoTime();

            regista(antes, depois);

        }
    }

    public static void main(String[] args) throws Exception {
        for(int i=0; i<10; i++)
            new Run().start();

        Thread.sleep(5000);

        partida();

        Thread.sleep(10000);

        imprime();

        System.exit(0);

    }
}
